<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<?php 
include 'koneksi.php';
?>
<div class="container mt-3">
	<a class="btn btn-primary btn-sm" href="?merk">Tagihan PKB Merk Kendaraan</a>
	<a class="btn btn-primary btn-sm" href="?tahun">Pembayaran PKB Per Tahun</a>

	<div class="container-fluid">
		<?php 
		if(isset($_GET['merk']))
		{
			?>
			<canvas id="myChart" style="height:500"></canvas>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.1/chart.js"></script>
			<?php
			$gm=mysqli_query($kon,"select * from pkb group by merk");
			while($g=mysqli_fetch_array($gm))
			{
				$label[] = $g['merk'];

				$tots=mysqli_query($kon,"select sum(tagihan) as totaltag,merk from pkb where merk='$g[merk]'");
				while($t=mysqli_fetch_array($tots))
				{
					$jumlahtagihan[]=$t['totaltag'];		
				}
				
			}

			
			?>
			<script>
			var ctx = document.getElementById("myChart").getContext('2d');
			var myChart = new Chart(ctx, {
				type: 'bar',
				data: {
					labels: <?php echo json_encode($label); ?>,
					datasets: [{
						label: 'Jumlah Tagihan',
						data: <?php echo json_encode($jumlahtagihan); ?>,
						borderWidth: 1,
						backgroundColor: ['rgb(0, 99, 212)'],
	                    borderColor: ['rgb(0, 99, 212)'],
						}]
				},
				options: {
					scales: {
						yAxes: [{
							ticks: {
								beginAtZero:true
							}
						}]
					}
				}
			});
			</script>
			<?php
		}
		elseif(isset($_GET['tahun']))
		{
			?>
			<canvas id="myChart" style="height:500"></canvas>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.1/chart.js"></script>
			<?php
				$gm=mysqli_query($kon,"select * from pkb group by entri");
				while($g=mysqli_fetch_array($gm))
				{
					$label[] = $g['entri'];

					$tots=mysqli_query($kon,"select sum(tagihan) as totaltag from pkb group by entri");
					while($t=mysqli_fetch_array($tots))
					{
						$jumlahtagihan[]=$t['totaltag'];		
					}
					
				}
		

			
			?>
			<script>
			var ctx = document.getElementById("myChart").getContext('2d');
			var myChart = new Chart(ctx, {
				type: 'bar',
				data: {
					labels: <?php echo json_encode($label); ?>,
					datasets: [{
						label: 'Jumlah Tagihan',
						data: <?php echo json_encode($jumlahtagihan); ?>,
						borderWidth: 1,
						backgroundColor: ['rgb(0, 99, 212)'],
	                    borderColor: ['rgb(0, 99, 212)'],
						}]
				},
				options: {
					scales: {
						yAxes: [{
							ticks: {
								beginAtZero:true
							}
						}]
					}
				}
			});
			</script>
			<?php
		}
		?>

	</div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>