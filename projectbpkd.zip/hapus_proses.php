<?php 
include 'koneksi.php';
mysqli_query($kon,"delete from pkb where id='$_GET[id]'");

?>
<script type="text/javascript">
	alert('Data berhasil dihapus');
	window.location='./';
</script>