<?php 
include 'koneksi.php';
$url=file_get_contents('https://samsat.bengkuluprov.go.id/pkb_dummy_data.json');
$data=json_decode($url,true);
foreach ($data as $value) {
	$cekkno=mysqli_query($kon,"select * from pkb where nopol='$value[Nopol]'");
	if(mysqli_num_rows($cekkno)==0)
	{
		$imp=mysqli_query($kon,"insert into pkb (nopol,jenis,merk,tahun,rangka,mesin,tagihan,entri) values 
					('$value[Nopol]','$value[JenisKendaraan]','$value[MerkKendaraan]','$value[TahunBuatan]','$value[NomorRangka]','$value[NomorMesin]','$value[TotalTagihan]','$value[TglNtpd]')");
		if($imp)
		{
			echo $value['Nopol'].' Berhasil import<br>';
		}
		else
		{
			echo $value['Nopol'].' Gagal import<br>';	
		}

		
	}	
	else{
		echo $value['Nopol'].' Sudah tersedia<br>';
	}					   
}
echo "<a href='./'>Kembali</a>";
?>