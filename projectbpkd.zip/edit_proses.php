<?php 
include 'koneksi.php';
$jenis= addslashes($_POST['jenis']);
$merk=addslashes($_POST['merk']);
$tahun=addslashes($_POST['tahun']);
$rangka=addslashes($_POST['rangka']);
$mesin=addslashes($_POST['mesin']);
$id=$_POST['id'];

$simpan=mysqli_query($kon,"update pkb set jenis='$jenis', merk='$merk', tahun='$tahun', rangka='$rangka', mesin='$mesin' where id='$id'");
if($rangka==$mesin)
{
	?>
	<script type="text/javascript">
		alert('Data gagal diupdate. Nomor Rangka dan Mesin tidak boleh sama');
		history.back();
	</script>
	<?php
}
else
{
	if($simpan)
	{
		?>
		<script type="text/javascript">
			alert('Data berhasil diupdate');
			window.location='./';
		</script>
		<?php
	}
	else
	{
		?>
		<script type="text/javascript">
			alert('Data gagal diupdate');
			history.back();
		</script>
		<?php
	}
	
}


?>