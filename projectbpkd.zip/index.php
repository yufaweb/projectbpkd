<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<?php 
include 'koneksi.php';
?>
<div class="container mt-3">

	<a class="btn btn-primary btn-sm" href="?tambah">Tambah Kendaraan</a>
	<a class="btn btn-primary btn-sm" href="importdata.php">Import Data</a>
	<a class="btn btn-primary btn-sm" href="tagihanpkb.php">Jumlah Tagihan PKB</a>
	<div class="row">
		
		<?php 
		if(isset($_GET['tambah']))
		{
			?>
			<hr>
			<div class="row">
				<form method="post" action="tambah_proses.php">
					<div class="form-group col-sm-4">
						<label>Jenis Kendaraan</label>
						<input type="text" name="jenis" class="form-control" required>
					</div>	
					<div class="form-group col-sm-4">
						<label>Merk</label>
						<input type="text" name="merk" class="form-control" required>
					</div>	
					<div class="form-group col-sm-4">
						<label>Tahun Kendaraan</label>
						<input type="number" name="tahun" class="form-control" required>
					</div>	
					<div class="form-group col-sm-4">
						<label>Nomor Rangka</label>
						<input type="text" name="rangka" class="form-control" required>
					</div>	
					<div class="form-group col-sm-4">
						<label>Nomor Mesin</label>
						<input type="text" name="mesin" class="form-control" required>
					</div>	
					<div class="form-group col-sm-4">
						<br>
						<button class="btn btn-primary btn-sm" name="simpan">Simpan</button>
					</div>	
				</form>
			</div>
			<hr>
			<?php 
		}
		elseif(isset($_GET['edit']))
		{
			$id=$_GET['id'];
			$e=mysqli_fetch_array(mysqli_query($kon,"select * from pkb where id='$id'"));
			?>
			<hr>
			<div class="row">
				<form method="post" action="edit_proses.php">
					<div class="form-group col-sm-4">
						<label>Jenis Kendaraan</label>
						<input type="hidden" name="id" value="<?php echo $e['id'];?>">
						<input type="text" name="jenis" class="form-control" required value="<?php echo $e['jenis'];?>">
					</div>	
					<div class="form-group col-sm-4">
						<label>Merk</label>
						<input type="text" name="merk" class="form-control" required value="<?php echo $e['merk'];?>">
					</div>	
					<div class="form-group col-sm-4">
						<label>Tahun Kendaraan</label>
						<input type="number" name="tahun" class="form-control" required value="<?php echo $e['tahun'];?>">
					</div>	
					<div class="form-group col-sm-4">
						<label>Nomor Rangka</label>
						<input type="text" name="rangka" class="form-control" required value="<?php echo $e['rangka'];?>">
					</div>	
					<div class="form-group col-sm-4">
						<label>Nomor Mesin</label>
						<input type="text" name="mesin" class="form-control" required value="<?php echo $e['mesin'];?>">
					</div>	
					<div class="form-group col-sm-4">
						<br>
						<button class="btn btn-primary btn-sm" name="simpan">Simpan</button>
					</div>	
				</form>
			</div>
			<hr>
			<?php
		}
		elseif(isset($_GET['detail']))
		{
			$id=$_GET['id'];
			$mesin=$_GET['mesin'];
			$rangka=$_GET['rangka'];
			$gk=mysqli_fetch_array(mysqli_query($kon,"select * from pkb where id='$id'"));
			$url=file_get_contents('https://samsat.bengkuluprov.go.id/pkb_dummy_data.json');
			$data=json_decode($url,true);
			foreach ($data as $value) {
	   			if($value['NomorRangka']==$gk['rangka'])
	   			{

	   				echo "KodeBayar : ".$value['KodeBayar']."<br>";
			   		echo "Total Tagihan :".$value['TotalTagihan']."<br><hr>";	
	   			}

			   
			}
			$grup=group_by("MerkKendaraan",$data);
			echo var_export($grup);
			
		}
		?>	
		<div class="table-responsive">
			<table class="table table-responsive table-striped table-bordered">
				<thead>
					<th>No.</th>
					<th>Jenis Kendaraan</th>
					<th>Merk</th>
					<th>Tahun Pembuatan</th>
					<th>Nomor Rangka/Mesin</th>
					<th>Entri</th>
					<th>Aksi</th>
				</thead>
				<?php 
				$dk=mysqli_query($kon,"select * from pkb order by id desc");
				$no=1;
				while ($d=mysqli_fetch_array($dk)) {
					?>
					<tr>
						<td><?php echo $no;?></td>
						<td><?php echo $d['jenis'];?></td>
						<td><?php echo $d['merk'];?></td>
						<td><?php echo $d['tahun'];?></td>
						<td><?php echo $d['rangka'];?>/<?php echo $d['mesin'];?></td>
						<td><?php echo $d['entri'];?></td>
						<td>
							<a class="btn btn-primary btn-sm" href="?detail&id=<?php echo $d['id'];?>&rangka=<?php echo $d['rangka'];?>&mesin=<?php echo $d['mesin'];?>">Detail</a>
							<a class="btn btn-warning btn-sm" href="?edit&id=<?php echo $d['id'];?>">Edit</a>
							<a class="btn btn-danger btn-sm" href="hapus_proses.php?id=<?php echo $d['id'];?>" onclick="return confirm('Anda yakin ingin menghapus data ini ?')">Hapus</a>
						</td>
					</tr>
					<?php
					$no++;
				}
				?>
			</table>
		</div>
	</div>
</div>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>