<?php 
include 'koneksi.php';
$jenis= addslashes($_POST['jenis']);
$merk=addslashes($_POST['merk']);
$tahun=addslashes($_POST['tahun']);
$rangka=addslashes($_POST['rangka']);
$mesin=addslashes($_POST['mesin']);

$simpan=mysqli_query($kon,"insert into pkb (jenis,merk,tahun,rangka,mesin) values ('$jenis','$merk','$tahun','$rangka','$mesin')");
if($rangka==$mesin)
{
	?>
	<script type="text/javascript">
		alert('Data gagal disimpan. Nomor Rangka dan Mesin tidak boleh sama');
		history.back();
	</script>
	<?php
}
else
{
	if($simpan)
	{
		?>
		<script type="text/javascript">
			alert('Data berhasil disimpan');
			window.location='./';
		</script>
		<?php
	}
	else
	{
		?>
		<script type="text/javascript">
			alert('Data gagal disimpan');
			history.back();
		</script>
		<?php
	}
	
}

?>